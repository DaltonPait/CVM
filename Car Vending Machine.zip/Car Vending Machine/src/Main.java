
public class Main extends CVM_Functions {

	public static void main(String[] args) {
		intro();
		brandSelection();
		decisionSelection();
		
		
	}

}