import java.util.Scanner;

public class CVM_Functions {
	static Scanner userInput = new Scanner(System.in);
	
	public static String[] carList = {"Audi", "BMW", "Land Rover", "Mercedes-Benz", "Porsche"};
	
	public static String[][] audiList = {
			{"RS e-tron GT", "$140,000"}, 
			{"RS Q8", "$115,000"}, 
			{"R8 Spyder", "$155,000"}, 
			{"SQ7", "$85,000"}, 
			{"TT RS", "$73,000"}};

	public static String[][] bmwList = {
			{"Alpina B8", "$140,000"}, 
			{"Alpina XB7", "$140,000"}, 
			{"M8 Gran Coupe", "$130,000"}, 
			{"M8 Convertible", "$140,000"}, 
			{"Z4 Roadster", "$50,000"}};

	public static String[][] landRoverList = {
			{"Defender", "$45,000"}, 
			{"Discovery", "$55,000"}, 
			{"Range Rover", "$95,000"}, 
			{"Range Rover Sport", "$70,000"}};

	public static String[][] mercedesBenzList = {
			{"G-Class SUV", "$130,000"}, 
			{"Maybach GLS SUV", "$160,000"}, 
			{"Maybach S-Class", "$175,000"}, 
			{"S-Class Coupe", "$130,000"}, 
			{"S-Class Cabriolet","$140,000"}};

	public static String[][] porscheList = {
			{"Cayenne", "$70,000"}, 
			{"Panamera", "$90,000"}, 
			{"718", "$60,000"},
			{"911", "$100,000"}};
	
	public static String audiLink = "https://www.audiusa.com";
	public static String bmwLink = "https://www.bmwusa.com";
	public static String landRoverLink = "https://www.landroverusa.com";
	public static String mercedesBenzLink = "https://www.mbusa.com";
	public static String porscheLink = "https://www.porsche.com";
	
	static String userName;
	static int userBrand;
	static int userModel;
	static char userApproval;
	static int userDecision;

	public static void intro() {
		System.out.println("Hello and welcome to the virtual luxury car vending machine. What is your name? ");
		userName = userInput.nextLine();
		System.out.println("\nNice to meet you, " + userName + "!");

	}
	
	public static void brandSelection() {
		System.out.println("\nWe currently carry 24 total models from 5 different luxury car brands."
				+ "\nThe brands we carry are:"
				+ "\n1.Audi"
				+ "\n2.BMW"
				+ "\n3.Land Rover"
				+ "\n4.Mercedes-Benz"
				+ "\n5.Porsche");
		System.out.println("\nWhat brand of car are you interested in buying, " + userName +"? (1-5)");
		userBrand = userInput.nextInt();
		System.out.println();
		printModels(userBrand);
		modelSelection();
	}
	
	public static void modelSelection() {
		System.out.println("\nAbove you see the models for the brand you have selected. "
				+ "\nAre you happy with this brand (y)?"
				+ "\nOr would you like to select a different brand (n)?"
				+ "\nPlease enter 'y' or 'n': ");
		userApproval = userInput.next().charAt(0);
		if (Character.toUpperCase(userApproval) == 'N') 
			brandSelection();
		else if (Character.toUpperCase(userApproval) == 'Y') {
			System.out.println("\nGreat! Now which model are you interested in buying?"
					+ "\nPlease enter the model's list number (1, 2, 3...): ");
			userModel = userInput.nextInt()-1;
		}
		else {
			System.out.println("\nSorry, but the value of your input was invalid. "
					+ "\nFor example..."
					+ "\n$40000\t\t\t1.Mustang"
					+ "\nEnter '1' if you wish to select Mustang."
					+ "\nPlease enter the list number of the model you wish to purchase: ");
			userModel = userInput.nextInt()-1;
		}
	}
	
	public static void decisionSelection() {
		System.out.println();
		if (userBrand == 1)
			System.out.println("You chose: " + audiList[userModel][0] + " for " + audiList[userModel][1]);
		else if (userBrand == 2)
			System.out.println("You chose: " + bmwList[userModel][0] + " for " + bmwList[userModel][1]);
		else if (userBrand == 3)
			System.out.println("You chose: " + landRoverList[userModel][0] + " for " + landRoverList[userModel][1]);
		else if (userBrand == 4)
			System.out.println("You chose: " + mercedesBenzList[userModel][0] + " for " + mercedesBenzList[userModel][1]);
		else if (userBrand == 5)
			System.out.println("You chose: " + porscheList[userModel][0] + " for " + porscheList[userModel][1]);
		System.out.println("Would you like to complete your purchase?"
				+ "\n1. Yes, I would like to buy the car."
				+ "\n2. No, I would not like to buy the car.");
		userDecision = userInput.nextInt();
		System.out.println();
		if (userDecision == 1)
			System.out.println("Congratulations on your new car.");
		else if (userDecision == 2)
			System.out.println("That is okay - maybe next time. Come visit the virtual luxury car vending machine another time!");
		else {
			System.out.println("You did not enter valid input please enter yes, or no.");
			decisionSelection();
		}
	}
		
	public static void printModels(int carBrand) {// for this method, I could use switch case, but I like nested if else statements more.
		System.out.println("The models of this brand that we carry are as follows: ");
		if (carBrand == 1)
			for (int i = 0; i < audiList.length; i++) {
				if (i >= 3)
					System.out.println(audiList[i][1] + "\t\t\t" + (i + 1) + ". " + audiList[i][0]);
				else System.out.println(audiList[i][1] + "\t\t" + (i + 1) + ". " + audiList[i][0]);
			}
		else if (carBrand == 2)
			for (int i = 0; i < bmwList.length; i++) {
				if (i==4)
					System.out.println(bmwList[i][1] + "\t\t\t" + (i + 1) + ". " + bmwList[i][0]);
				else System.out.println(bmwList[i][1] + "\t\t" + (i + 1) + ". " + bmwList[i][0]);
			}
		else if (carBrand == 3)
			for (int i = 0; i < landRoverList.length; i++) {
				System.out.println(landRoverList[i][1] + "\t\t" + (i + 1) + ". " + landRoverList[i][0]);
			}
		else if (carBrand == 4)
			for (int i = 0; i < mercedesBenzList.length; i++) {
				System.out.println(mercedesBenzList[i][1] + "\t\t" + (i + 1) + ". " + mercedesBenzList[i][0]);
		}
		else if (carBrand == 5)
			for (int i = 0; i < porscheList.length; i++) {
				if (i==3)
					System.out.println(porscheList[i][1] + "\t\t" + (i + 1) + ". " + porscheList[i][0]);
				else System.out.println(porscheList[i][1] + "\t\t\t" + (i + 1) + ". " + porscheList[i][0]);
			}
		else {
			System.out.println("\nSorry, but the value of your input was invalid please select an integer value 1-5. ");
			userBrand = userInput.nextInt();
			printModels(userBrand);
		}		
	}
	
}
